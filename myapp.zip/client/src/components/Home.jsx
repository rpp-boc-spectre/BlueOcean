import React from "react";

export default function Home() {
  return (
    <div>
      <h1>I am rendered with React!</h1>
    </div>
  )
}